package com.tfk.practicalexam;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity implements OnClickListener
{
    EditText Name, Email, Message;
    Button Save, Delete, Update, View, ViewAll;
    SQLiteDatabase db;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Name=(EditText)findViewById(R.id.editText_name);
        Email=(EditText)findViewById(R.id.editText_email);
        Message=(EditText)findViewById(R.id.editText_message);
        Save=(Button)findViewById(R.id.button_save);
        Delete=(Button)findViewById(R.id.button_delete);
        Update=(Button)findViewById(R.id.button_update);
        View=(Button)findViewById(R.id.button_view);
        ViewAll=(Button)findViewById(R.id.button_viewAll);

        Save.setOnClickListener(this);
        Delete.setOnClickListener(this);
        Update.setOnClickListener(this);
        View.setOnClickListener(this);
        ViewAll.setOnClickListener(this);

        // Creating database and table
        db=openOrCreateDatabase("StudentDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS student(name VARCHAR, email VARCHAR, message VARCHAR);");
    }
    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==Save)
        {
            // Checking for empty fields
            if(Name.getText().toString().trim().length()==0||
                    Email.getText().toString().trim().length()==0||
                    Message.getText().toString().trim().length()==0)
            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO student VALUES('"+Name.getText()+"','"+Email.getText()+
                    "','"+Message.getText()+"');");
            showMessage("Success", "Record added");
            clearText();
        }
        // Deleting a record from the Student table
        if(view==Delete)
        {
            // Checking for empty roll number
            if(Name.getText().toString().trim().length()==0)
            {
                showMessage("Error", "Please enter Name");
                return;
            }
            Cursor c=db.rawQuery("SELECT * FROM student WHERE name='"+Name.getText()+"'", null);
            if(c.moveToFirst())
            {
                db.execSQL("DELETE FROM student WHERE name='"+Name.getText()+"'");
                showMessage("Success", "Record Deleted");
            }
            else
            {
                showMessage("Error", "Invalid Name");
            }
            clearText();
        }
        // Updating a record in the Student table
        if(view==Update)
        {
            // Checking for empty roll number
            if(Name.getText().toString().trim().length()==0)
            {
                showMessage("Error", "Please enter Name");
                return;
            }
            Cursor c=db.rawQuery("SELECT * FROM student WHERE rollno='"+Name.getText()+"'", null);
            if(c.moveToFirst()) {
                db.execSQL("UPDATE student SET email='" + Email.getText() + "',message='" + Message.getText() +
                        "' WHERE name='"+Name.getText()+"'");
                showMessage("Success", "Record Modified");
            }
            else {
                showMessage("Error", "Invalid Name");
            }
            clearText();
        }
        // Display a record from the Student table
        if(view==View)
        {
            // Checking for empty roll number
            if(Name.getText().toString().trim().length()==0)
            {
                showMessage("Error", "Please enter Name");
                return;
            }
            Cursor c=db.rawQuery("SELECT * FROM student WHERE name='"+Name.getText()+"'", null);
            if(c.moveToFirst())
            {
                Email.setText(c.getString(1));
                Message.setText(c.getString(2));
            }
            else
            {
                showMessage("Error", "Invalid Name");
                clearText();
            }
        }
        // Displaying all the records
        if(view==ViewAll)
        {
            Cursor c=db.rawQuery("SELECT * FROM student", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {
                buffer.append("Name: "+c.getString(0)+"\n");
                buffer.append("Email: "+c.getString(1)+"\n");
                buffer.append("Message: "+c.getString(2)+"\n\n");
            }
            showMessage("Student Details", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        Builder builder=new Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText()
    {
        Name.setText("");
        Email.setText("");
        Message.setText("");
        Name.requestFocus();
    }
}