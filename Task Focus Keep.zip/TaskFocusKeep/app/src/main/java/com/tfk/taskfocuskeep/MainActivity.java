package com.tfk.taskfocuskeep;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.tfk.taskfocuskeep.Adapter.TasksAdapter;
import com.tfk.taskfocuskeep.Model.TasksModel;
import com.tfk.taskfocuskeep.Utils.DatabaseHandler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity implements DialogCloseListener
{
    private RecyclerView recycler_tasks;
    private TasksAdapter tasksAdapter;
    private FloatingActionButton fab;
    private ImageButton button_help;

    private List<TasksModel> tasksList;
    private DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        db = new DatabaseHandler(this);
        db.openDatabase();

        //tasksList = new ArrayList<>();

        tasksAdapter = new TasksAdapter(db, MainActivity.this);
        recycler_tasks = findViewById(R.id.recycler_tasks);
        recycler_tasks.setLayoutManager(new LinearLayoutManager(this));
        recycler_tasks.setAdapter(tasksAdapter);
        button_help = findViewById(R.id.button_help);

        button_help.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialogBox();
            }
        });

        fab = findViewById(R.id.fab);

        ItemTouchHelper itemTouchHelper = new
                ItemTouchHelper(new RecyclerItemTouchHelper(tasksAdapter));
        itemTouchHelper.attachToRecyclerView(recycler_tasks);

        tasksList = db.getAllTasks();
        //Collections.reverse(tasksList);
        tasksAdapter.setTasks(tasksList);

        fab.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                AddNewTask.newInstance().show(getSupportFragmentManager(), AddNewTask.TAG);
            }
        });
    }

    @Override
    public void handleDialogClose(DialogInterface dialog)
    {
        tasksList = db.getAllTasks();
        //Collections.reverse(tasksList);
        tasksAdapter.setTasks(tasksList);
        tasksAdapter.notifyDataSetChanged();
    }

    void dialogBox()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Help");
        builder.setMessage("1. Add new tasks by pressing the floating button.\n" +
                "2. Edit tasks by swiping the task to the right.\n" +
                "3. Delete tasks by swiping the task to the left.\n" +
                "4. The tasks list is scrollable.");
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}