package com.tfk.taskfocuskeep;

import android.app.Activity;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.tfk.taskfocuskeep.Model.TasksModel;
import com.tfk.taskfocuskeep.Utils.DatabaseHandler;

import org.w3c.dom.Text;

public class AddNewTask extends BottomSheetDialogFragment
{
    public static final String TAG = "ActionBottomDialog";

    private EditText editText_newTask;
    private Button button_save;
    private DatabaseHandler db;

    public static AddNewTask newInstance()
    {
        return new AddNewTask();
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setStyle(STYLE_NORMAL, R.style.DialogStyle);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.activity_new_task, container, false);
        getDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);
        editText_newTask = getView().findViewById(R.id.editText_newTask);
        button_save = getView().findViewById(R.id.button_newTask);
        button_save.setEnabled(false);

        boolean isUpdate = false;
        final Bundle bundle = getArguments();
        if(bundle != null)
        {
            isUpdate = true;
            String task = bundle.getString("task");
            editText_newTask.setText(task);
            if(task.length() > 0)
            {
                button_save.setTextColor(ContextCompat.getColor(getContext(), R.color.blue_500));
            }
        }

        db = new DatabaseHandler(getActivity());
        db.openDatabase();

        editText_newTask.addTextChangedListener(new TextWatcher()
        {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {
                if(s.toString().equals(""))
                {
                    button_save.setEnabled(false);
                    button_save.setTextColor(ContextCompat.getColor(getContext(), R.color.gray));
                }
                else
                {
                    button_save.setEnabled(true);
                    button_save.setTextColor(ContextCompat.getColor(getContext(), R.color.blue_500));
                }
            }

            @Override
            public void afterTextChanged(Editable s)
            {

            }
        });

        boolean finalIsUpdate = isUpdate;
        button_save.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String text = editText_newTask.getText().toString();
                if(finalIsUpdate)
                {
                    db.updateTask(bundle.getInt("id"), text);
                }
                else
                {
                    TasksModel task = new TasksModel();
                    task.setTask(text);
                    task.setStatus(0);
                    db.insertTask(task);
                }
                dismiss();
            }
        });
    }

    @Override
    public void onDismiss(@NonNull DialogInterface dialog)
    {
        Activity activity = getActivity();
        if(activity instanceof DialogCloseListener)
        {
            ((DialogCloseListener)activity).handleDialogClose(dialog);
        }
    }
}
