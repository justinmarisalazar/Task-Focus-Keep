package com.tfk.taskfocuskeep.Adapter;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import androidx.recyclerview.widget.RecyclerView;

import com.tfk.taskfocuskeep.AddNewTask;
import com.tfk.taskfocuskeep.MainActivity;
import com.tfk.taskfocuskeep.Model.TasksModel;
import com.tfk.taskfocuskeep.R;
import com.tfk.taskfocuskeep.Utils.DatabaseHandler;

import java.util.List;

public class TasksAdapter extends RecyclerView.Adapter<TasksAdapter.ViewHolder>
{
    private List<TasksModel> tasksList;
    private MainActivity activity;
    private DatabaseHandler db;

    public TasksAdapter(DatabaseHandler db, MainActivity activity)
    {
        this.db = db;
        this.activity = activity;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_task, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position)
    {
        db.openDatabase();

        final TasksModel item = tasksList.get(position);
        holder.task.setText(item.getTask());
        holder.task.setChecked(toBoolean(item.getStatus()));
        holder.task.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                if(buttonView.isPressed())
                {
                    if (isChecked)
                    {
                        db.updateStatus(item.getId(), 1);
                    } else
                    {
                        db.updateStatus(item.getId(), 0);
                    }
                }
            }
        });
    }

    private boolean toBoolean(int n)
    {
        return n != 0;
    }

    public int getItemCount()
    {
        return tasksList.size();
    }

    public Context getContext()
    {
        return activity;
    }

    public void setTasks(List<TasksModel> tasksList)
    {
        this.tasksList = tasksList;
        notifyDataSetChanged();
    }

    public void deleteItem(int position)
    {
        TasksModel item = tasksList.get(position);
        db.deleteTask(item.getId());
        tasksList.remove(position);
        notifyItemRemoved(position);
    }

    public void editItem(int position)
    {
        TasksModel item = tasksList.get(position);
        Bundle bundle = new Bundle();
        bundle.putInt("id", item.getId());
        bundle.putString("task", item.getTask());
        AddNewTask fragment = new AddNewTask();
        fragment.setArguments(bundle);
        fragment.show(activity.getSupportFragmentManager(), AddNewTask.TAG);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder
    {
        CheckBox task;

        ViewHolder(View view)
        {
            super(view);
            task = view.findViewById(R.id.checkbox_status);
        }
    }
}
